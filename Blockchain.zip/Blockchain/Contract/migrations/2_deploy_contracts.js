var databaseContract = artifacts.require("./Database.sol");

module.exports = function(deployer) {
      deployer.deploy(databaseContract);
}